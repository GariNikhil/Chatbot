# Chatbot — Development Phases

## Phase 0 — Discovery & Scaffolding (Current)

**Goal:** Establish repo structure, documentation, and configuration schema.

### Deliverables
- [ ] Repository root with `/docs`, `/house`, `/workspace`, `/.opencode`
- [ ] `docs/PRD.md` — product requirements (complete)
- [ ] `docs/PLAN.md` — this execution plan
- [ ] `docs/PHASES.md` — phase breakdown
- [ ] `docs/ROADMAP.md` — timeline
- [ ] `docs/DESIGN.md` — system architecture
- [ ] `docs/TASKS.md` — task breakdown
- [ ] `docs/RULES.md` — coding and project conventions
- [ ] `house/organization.yaml` — descriptive household manifest (not read at runtime)
- [ ] `house/characters/` — initial character definitions and system prompts (Nick + family/friends)
- [ ] `house/scenes/` — initial scene definitions

### Exit Criteria
- All docs exist and are internally consistent.
- `house/characters/` defines at least 3 agents + Nick; the manifest matches them.
- Character schema is documented and followed.

---

## Phase 1 — Core Chat Runtime

**Goal:** Nick can send messages to agents and receive in-character replies via the Chatbot server + LM Studio.

### Deliverables
- [ ] Chatbot server configured to connect to LM Studio at `http://localhost:1234/v1`
- [ ] Agent runtime loads characters from `house/characters/`
- [ ] Chat interface (workspace UI or minimal) sends user input to selected agent
- [ ] Agent replies stream back from LM Studio in-character
- [ ] Per-agent system prompts applied from `house/characters/<key>.yaml`

### Exit Criteria
- Nick can chat with all defined agents.
- Each agent maintains its personality in replies.
- No hardcoded agent responses; all generation comes from LM Studio.

---

## Phase 2 — Scenes & Scenarios

**Goal:** Organize agents into a scenario (whole story) and scenes (chapters) that act as workspaces for specific storylines.

### Deliverables
- [x] Scenario schema defined (`name`, `description`, `premise`, `participants`, `world_card`, story extras)
- [x] Scenario/authoring files in `house/scenarios/` load at runtime
- [x] Scene schema defined (`name`, `description`, `participants`, `location`, `world_card`, optional `scenario`)
- [x] Scene files stored in `house/scenes/`
- [x] UI allows selecting an active scene, grouped by scenario
- [x] Agents aware of the active scenario and scene when responding
- [x] Scenario and scene context injected into agent prompts in that order
- [x] Scenarios can claim several chapters at once (including all scenes) and the chat view offers a chapter switcher

### Exit Criteria
- At least 2 scenes defined (e.g., "Living Room Evening," "Weekend Trip").
- Switching scenes changes immediate context while a linked scenario's foundation persists.
- Scenario-level and scene-level tags stay separate.
- Chapters of one scenario can be switched from the chat view without merging their histories.

---

## Phase 3 — Durable Memory (Obsidian)

**Goal:** Agents remember past conversations across sessions via Obsidian vault.

### Deliverables
- [x] Obsidian vault path configured (default: workspace or external vault)
- [x] Memory entries written as Markdown files after significant conversations
- [x] Memory entries stored story → chapter → character (legacy character-first
      files remain readable)
- [x] Agent retrieves relevant memories before generating replies
- [x] Memory importance scoring (1–10) for retrieval prioritization

### Exit Criteria
- Agent references a past conversation detail in a new session.
- Memory files are human-readable Markdown in Obsidian.
- The Memories dashboard mirrors scenario → scene → character.

---

## Phase 4 — World Cards & Location Shifts

**Goal:** Dynamically change setting/mood via world cards and location-shift cards.

### Deliverables
- [ ] World card schema (`name`, `type`, `description`, `active`)
- [ ] Location-shift card schema
- [ ] UI to activate/deactivate cards
- [ ] Active cards injected into agent context/prompt

### Exit Criteria
- Activating a "Rainy Evening" world card changes agent tone/responses.
- Location-shift card moves the scene to a new setting.

---

## Phase 5 — Character Creation & Management

**Goal:** Users can add, edit, and delete characters without code changes.

### Deliverables
- [ ] UI form for creating a new character (nickname, gender, age, personality, appearance, role)
- [ ] Character validation (required fields, age range, etc.)
- [ ] Character deletion with confirmation
- [ ] New character immediately available for chat

### Exit Criteria
- Nick can create a fully functional new character via UI.
- New character appears in chat selection and responds in-character.

---

## Phase 6 — Polish, Testing & Release

**Goal:** Stabilize the application, fix bugs, and prepare for daily use.

### Deliverables
- [ ] workspace UI integrated and polished
- [ ] Error handling for LM Studio downtime
- [ ] Unit tests for character/scene loading
- [ ] Integration tests for chat flow
- [ ] README updated with final install/run instructions
- [ ] `.gitignore` and repo hygiene

### Exit Criteria
- Application runs end-to-end without crashes.
- All P0/P1 requirements from PRD verified.
- Repo is clean and documented for contributors.
