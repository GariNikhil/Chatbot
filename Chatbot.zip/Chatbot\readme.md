# Chatbot — Production Local Setup

## Stack
- **Chatbot server** — Node.js HTTP runtime (loaders, prompt assembly, chat streaming)
- **workspace** — visual multi-agent office/hive UI (static HTML/CSS/JS)
- **Obsidian** — durable knowledge base / long-term memory
- **LLM Provider** — local LLM inference server supporting LM Studio (`http://localhost:1234/v1`) or Ollama (`http://localhost:11434/v1`)

## Project Structure

```
Chatbot/
├── docs/                    # PRD, plan, phases, roadmap, design, tasks, rules
├── ui/                      # workspace chat UI (static HTML/CSS/JS)
├── server/                  # Local API: loaders, prompt assembly, chat streaming
├── house/                   # Characters, scenes, cards, and the org manifest
│   ├── organization.yaml  # Descriptive hierarchy only — not read at runtime
│   ├── characters/        # Runtime source of truth for agents (mom, dad, alex, soniya, jordan, priya, kaviya…)
│   ├── scenarios/         # Live story foundations (premise, relationships, world)
│   ├── scenes/            # Live chapters (name, participants, location, optional scenario)
│   ├── world cards/       # World, location-shift, and genre cards
│   └── tags.yaml          # Canonical tag catalog used by every create/edit form
├── workspace/             # Runtime workspace data (gitignored)
├── .opencode/             # OpenCode local state (gitignored)
├── opencode.json          # OpenCode config
├── .env.example           # Environment variable template
├── .gitignore             # Git ignore rules
└── readme.md              # This file
```

## Chatbot Organization

`house/organization.yaml` is a human-readable manifest of the household. The
server does **not** read it: `house/characters/*.yaml` is the runtime source of
truth, so adding a character file (or using the UI form) is enough to make an
agent available. The current roster is:

- **Nick** (user/owner, 28) — curious, sarcastic, loves technology
- **Mom** (parent, 45) — warm, caring, slightly overprotective, loves cooking
- **Dad** (parent, 47) — laid-back, handy, dry humor
- **Alex** (sibling, 19) — energetic gamer, tech-curious
- **Soniya** (sibling, 22) — creative artist, observant daydreamer
- **Jordan** (friend, 28) — tech geek, witty, loves open-source
- **Priya** (friend, 27) — energetic, sporty, upbeat
- **Kaviya** (sister-in-law, 27) — witty, nurturing, competitive, loves hosting

Agents are organized into **parent**, **sibling**, **sister_in_law**, and
**friend** roles.

## workspace UI

The chat UI lives in `ui/` and is served by the local server:

1. Start the server (`npm start` in `server/`).
2. Open `http://localhost:3001` in a browser.
3. Pick an agent and a scene (agents are filtered to scene participants), toggle
   world cards (via **Settings ▸ World Cards**), and chat — replies stream in
   from your configured LLM provider. Scenes linked to a scenario inherit that story's premise,
   relationships, tags, and world card.
4. Use **Settings ▸ Scenarios** to create the overall story and tick the scenes
   that belong to it (or use **Include all scenes**). Chapters can also be linked
   per scene in **Settings ▸ Scenes**; scenes without a scenario remain
   standalone. **Settings ▸ Characters** manages characters (saved to
   `house/characters/`). Characters, scenarios, scenes, and world cards all have
   a searchable tag picker backed by `house/tags.yaml`; tags are saved as stable
   ids in `tag_selections` and injected at the level they describe.
5. Browse **Settings ▸ Memories** to view memories grouped by story → chapter →
   character, including older character-first files.
6. Conversation history is saved in the browser per agent + scene, so
   reloading the page restores the chat you were in. While chatting, use the
   **Chapter** bar above the messages to jump between scenes of the current
   story (for example Living Room → Kitchen). Switching chapters keeps the
   scenario foundation but gives each scene its own immediate context.
7. Enable **Group chat** in the Agents panel to put every AI participant of
   the current scene into one room. The room has a single shared timeline per
   scene (switching participants does not split history), mentioned characters
   answer first, and empty/`[PASS]`/duplicate replies are skipped.
8. The **⚙ Settings** menu in the lower-left corner opens Scenarios, Scenes,
   Characters, World Cards, Memories, and a Help modal with setup steps and live
   server / LM Studio status.
9. The **☰** button in the chat header hides or shows the sidebar; the choice
   is remembered. On narrow screens the sidebar becomes an overlay drawer.

## Quick Start (recommended)

Double-click **`start.bat`** — it:

1. Checks LM Studio and starts it on port 1234 if needed (`lms`), loading `qwen3-4b` (if using LM Studio).
2. Starts the Chatbot server (`server/`, port 3001) unless it is already running.
3. Opens the workspace UI at `http://localhost:3001`. For Ollama, ensure `ollama serve` is running separately.

To stop the server, use **Settings ▸ End session** in the UI, or run
**`stop.bat`** (fixes "address already in use" on port 3001 when restarting
manually).

## Install

1. Clone or download this repository to any local folder.
2. Copy `.env.example` to `.env` and configure your LLM provider (LM Studio or Ollama).
3. Start your LLM provider:
   - **LM Studio**: Start local server at `http://localhost:1234/v1` and load a model
   - **Ollama**: Run `ollama serve` and `ollama pull <model>` (e.g., `ollama pull qwen3:4b`)
4. Install the server dependencies:
   `cd server; npm install`
5. Start the local API:
   `npm start`
6. Check readiness at `http://localhost:3001/health`.
7. Open the workspace UI at `http://localhost:3001`.
8. If you use OpenCode, point its provider at the same OpenAI-compatible endpoint and
   select the discovered model with `/models`.

The server binds to `127.0.0.1` by default. Set `HOST=0.0.0.0` only when you
intentionally want other machines on your LAN to reach it.

The server exposes `GET /agents`, `GET /scenes`, `GET /scenarios`, `GET /cards`,
`GET /tags`, `GET /models` (loaded models from your LLM provider), `GET /health` (reports provider reachability and loaded models), streaming `POST /chat`, scene CRUD via
`POST /scenes`, `PUT/DELETE /scenes/:key`, scenario CRUD via `POST /scenarios`,
`PUT/DELETE /scenarios/:key`, card creation/editing/activation via `POST /cards`,
`PUT/PATCH /cards/:key`, character CRUD via `POST /characters`,
`PUT/DELETE /characters/:key`, and memory browsing/deletion via
`GET /memories` (grouped story → chapter → character) and
`DELETE /memories/:path` (for example
`/memories/scenarios/the_arranged_marriage/the_first_meeting/mom/2026-10-27`; the
legacy `/memories/:character/:date` form still works). `GET /tags` returns
the `house/tags.yaml` catalog; add `?target=character|scenario|scene|card` to
filter by applicability. `POST /shutdown` stops the server (used by
**Settings ▸ End session**).

Write endpoints require `Content-Type: application/json` (otherwise `415`),
JSON bodies must be objects, and oversized bodies return `413`. The chat
request accepts `agentNickname`, `sceneName`, `message`, optional `model`,
optional `history` (up to 50 turns), and optional `activeCards` (omitting it
uses the persisted card activation state). Adding `characterNicknames` instead
of `agentNickname` runs a group turn: each listed AI character replies in
sequence against one shared history, mentioned characters go first, `[PASS]` and
duplicate replies are skipped, and at most eight responses are generated. A
scene may be addressed by its file key or display name. Its `world_card` is
always included, and if the scene links to a scenario, the scenario foundation
and scenario `world_card` are included too. Scenario create/update accepts an
optional `scenes` list of scene keys or names: listed chapters are linked, and
linked chapters left out become standalone. Omitting `scenes` leaves existing
links untouched. A placeholder model id resolves to
the first loaded model from your provider automatically.
Conversation exchanges for memory-enabled characters are written as Markdown
under the story hierarchy:
`<OBSIDIAN_VAULT_PATH>/Chatbot/Memories/scenarios/<story>/<chapter>/<character>/<date>.md`.
Scenes without a story (including free chat) use `standalone/<chapter>/<character>/`.
Every entry records its `scenario`, `scene`, `timestamp`, and importance in
frontmatter, and recall is still limited to the same exact scene. Older
`Memories/<character>/<date>.md` files remain readable and visible in the
dashboard. The memory root defaults to `workspace/memory/Chatbot/Memories`.

## Documentation

| Doc               | Description                                                            |
| ----------------- | ---------------------------------------------------------------------- |
| `docs/PRD.md`     | Product requirements, entities, functional/non-functional requirements |
| `docs/PLAN.md`    | Execution plan, milestones, decision log                               |
| `docs/PHASES.md`  | Six development phases with deliverables and exit criteria             |
| `docs/ROADMAP.md` | 8-week timeline, dependencies, risks, success metrics                  |
| `docs/DESIGN.md`  | System architecture, data flow, YAML schemas, memory model             |
| `docs/TASKS.md`   | Per-phase task checklist (T-0.1 through T-6.6)                         |
| `docs/RULES.md`   | Naming conventions, commit rules, testing rules, definition of done    |

## Next Steps

See `docs/TASKS.md` for phase status. The server and CRUD paths are covered by
automated tests; a live browser walkthrough with LM Studio is the remaining
manual check.
