# Chatbot — Product Requirements Document (PRD)

## 1. Overview

**Chatbot** is a locally-hosted, hierarchical multi-agent chat application that simulates a household of family members and friends. Each agent is a distinct character with its own nickname, gender, age, personality, and appearance. The primary user character is `{{user}}`, also known as **Nick**. Agents can speak directly to Nick, and the system supports **scenes/scenarios** that act as workspaces for specific storylines.

The stack is intentionally local and private:
- **Chatbot server** — Node.js agent runtime / prompt orchestration
- **LM Studio** — local LLM inference server
- **workspace** — visual multi-agent office/hive UI
- **Obsidian** — durable knowledge base / long-term memory

Scenarios are live story foundations in `house/scenarios/`. A scenario defines
the overall story (premise, relationship dynamics, tone, themes, and world
facts), while scenes in `house/scenes/` are the chapters inside it. Scenes may
link to one scenario or remain standalone.

---

## 2. Goals

| Goal                          | Description                                                                            |
| ----------------------------- | -------------------------------------------------------------------------------------- |
| Local-first privacy           | All conversations and memories run locally; no cloud LLM dependency.                   |
| Hierarchical agents           | Family/friend agents organized in a hierarchy with defined roles and relationships.    |
| Character-driven              | Each agent has a persistent identity (nickname, gender, age, personality, appearance). |
| Scenes & scenarios            | A scenario is the whole story; scenes are chapters with their own immediate context. |
| Durable memory                | Obsidian-backed knowledge base for long-term character memory and world state.         |
| Extensible character creation | Users can add new characters, location-shift cards, and world cards.                   |

---

## 3. User Stories

### As Nick (the user / {{user}})
- I want to chat directly with any family member or friend agent.
- I want to switch between chapters of one story, keeping its premise and
  relationship dynamics while each scene changes the immediate situation.
- I want each agent to remember past conversations from the current scene and reference them later.
- I want to add new characters to the house with custom traits.
- I want to use location-shift cards and world cards to change the setting dynamically.
- I want to add new scenarios and scenes to the house with custom traits and
  link chapters to the story they belong to.


### As a Family/Friend Agent
- I have a defined personality, age, gender, and appearance.
- I can speak to Nick directly, in-character.
- I can respond differently based on the active scene.
- I retain memory of previous interactions across sessions.

---

## 4. Core Entities

### 4.1 Character
| Field          | Type    | Required | Description                            |
| -------------- | ------- | -------- | -------------------------------------- |
| nickname       | string  | Yes      | Display name of the character          |
| gender         | string  | Yes      | Gender identity                        |
| age            | integer | Yes      | Age in years, 18–120                   |
| personality    | string  | Yes      | Free-text personality description      |
| appearance     | string  | Yes      | Free-text physical description         |
| role           | string  | No       | Position in the family/house hierarchy |
| system_prompt  | string  | No       | LLM system prompt for this agent       |
| memory_enabled | boolean | No       | Whether Obsidian memory is active      |

### 4.2 Scenario
| Field                 | Type     | Required | Description |
| --------------------- | -------- | -------- | ----------- |
| name                  | string   | Yes      | Story title (e.g., "The Arranged Marriage") |
| description           | string   | No       | Overall story summary |
| participants          | string[] | No       | Recurring cast; scenes still choose who is present |
| world_card            | string   | No       | World card applied to every linked chapter |
| premise               | string   | No       | How the story begins and what led here |
| relationship_dynamics | string   | No       | How the central relationship starts and evolves |
| central_conflict      | string   | No       | Core tension driving the story |
| narrative_direction   | string   | No       | Where the story is heading |
| tone, themes, genre   | string   | No       | Story-wide style and subject matter |
| tag_selections        | object   | No       | Story-level tags from `house/tags.yaml` |

Unknown extra fields used by existing templates (such as `story_hook`,
`opening_message`, or suggested locations) are preserved and included in the
scenario prompt block.

### 4.3 Scene
| Field        | Type     | Required | Description                               |
| ------------ | -------- | -------- | ----------------------------------------- |
| name         | string   | Yes      | Scene title (e.g., "Living Room Evening") |
| description  | string   | No       | Narrative description of the setting      |
| participants | string[] | Yes      | List of character nicknames present       |
| location     | string   | No       | Physical or virtual location              |
| world_card   | string   | No       | Reference to an active world card         |
| scenario     | string   | No       | Story this chapter belongs to; null = standalone |

Unknown extra fields (for example `tags` and `interactions`) are preserved and
included in the prompt.

### 4.4 World Card / Location-Shift Card
| Field       | Type    | Required | Description                           |
| ----------- | ------- | -------- | ------------------------------------- |
| name        | string  | Yes      | Card title                            |
| type        | string  | Yes      | "world", "location_shift", or "genre" |
| description | string  | Yes      | Effect on setting/mood                |
| active      | boolean | No       | Whether the card is currently applied |

### 4.5 Memory Entry
Memories are stored under their story and chapter first, then the character:
`scenarios/<scenario>/<scene>/<character>/<date>.md`. Scenes without a story use
`standalone/<scene>/<character>/`. Legacy character-first files
`<character>/<date>.md` remain readable and appear under **Standalone scenes**.

| Field        | Type     | Required | Description                        |
| ------------ | -------- | -------- | ---------------------------------- |
| character    | string   | Yes      | Owning character nickname          |
| scenario     | string   | No       | Story display name                 |
| scenario_key | string   | No       | Story folder key (empty = standalone) |
| scene        | string   | No       | Chapter where the memory was formed |
| scene_key    | string   | No       | Chapter folder key                 |
| content      | string   | Yes      | Memory text                        |
| timestamp    | datetime | Yes      | When the memory was created        |
| importance   | integer  | No       | 1–10 importance score              |

---

## 5. Functional Requirements

| ID    | Requirement                                                                  | Priority |
| ----- | ---------------------------------------------------------------------------- | -------- |
| FR-01 | Nick can send a message to any agent and receive an in-character reply.      | P0       |
| FR-02 | Agents respond using their defined personality, age, gender, and appearance. | P0       |
| FR-03 | Users can create, edit, and delete characters.                               | P0       |
| FR-04 | Users can create, edit, and delete scenarios and scenes, link several scenes to a scenario at once (including "all scenes"), and detach them. | P0 |
| FR-05 | Agents can be assigned to one or more scenes; a scenario lists its recurring cast. | P0 |
| FR-06 | Conversation history persists per character and per scene (browser storage); switching scenes does not merge timelines. | P1 |
| FR-07 | Long-term memory is stored in Obsidian under story → chapter → character and retrieved contextually per exact scene; the dashboard groups it the same way. | P1 |
| FR-08 | Users can activate world cards and location-shift cards; scenario and scene world cards apply automatically. | P1 |
| FR-09 | System prompts are defined per agent in `house/characters/<key>.yaml`.       | P0       |
| FR-10 | LM Studio serves as the local LLM backend via OpenAI-compatible API.         | P0       |
| FR-11 | Scenario foundation, character traits, world cards, scene context, and history are assembled in that order. | P0 |
| FR-12 | While chatting, users can switch directly between the chapters of the active scenario without leaving the chat view. | P0 |

---

## 6. Non-Functional Requirements

| ID    | Requirement                                                                    |
| ----- | ------------------------------------------------------------------------------ |
| NF-01 | All LLM inference runs locally via LM Studio; no external API calls.           |
| NF-02 | Configuration and character data stored as YAML/Markdown files (git-friendly). |
| NF-03 | UI provided by the workspace (visual multi-agent office/hive).                |
| NF-04 | Agent orchestration handled by the local Node.js Chatbot server.              |
| NF-05 | Obsidian vault used as the durable knowledge base.                             |

---

## 7. Out of Scope

- Mobile apps (initial release is desktop/local only).
- Multi-user / multi-player support (single user: Nick).
- Cloud deployment or SaaS hosting.
- Voice synthesis / TTS (text-only for v1).
- Image generation for character appearances (appearance is text description only).

---

## 8. Success Criteria

- [ ] Nick can chat with at least 3 predefined family/friend agents.
- [ ] Each agent maintains consistent personality across conversations.
- [ ] Switching scenes changes immediate context while a linked scenario's premise and relationship dynamics persist.
- [ ] All chapters of a scenario keep their own history and memories without leaking into each other.
- [ ] Scenario-level and scene-level tags are stored and injected separately.
- [ ] A user chatting in one chapter can switch to another chapter of the same scenario from the chat view, keeping the story foundation and per-scene history.
- [ ] Conversation history persists across application restarts.
- [ ] New characters can be added via YAML configuration without code changes.

