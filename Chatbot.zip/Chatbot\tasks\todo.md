# note.md Features — Task List

## Phase 1: Sidebar toggle
- [x] Task 1: Add hamburger toggle, desktop collapse, mobile drawer, persistence, and accessibility.

## Checkpoint: Sidebar
- [x] `node --check ui/app.js` passes
- [x] Toggle state survives reload; layout has no overlap at desktop/mobile widths

## Phase 2: Tag foundation
- [x] Task 2: Create canonical `house/tags.yaml` from the existing tag guide.
- [x] Task 3: Add tag loader/validator, `GET /tags`, and loader persistence for `tag_selections`.
- [x] Task 4: Inject character, scene, and card tags into the prompt.

## Checkpoint: Tag backend
- [x] `npm test` passes
- [x] Unknown/legacy tags do not break listings or chat

## Phase 3: Tag UI
- [x] Task 5: Build reusable searchable/collapsible tag picker and fetch `/tags`.
- [x] Task 6: Integrate picker into character and scene forms with edit/reload round-trip.
- [x] Task 7: Add world-card editing plus tag integration.

## Checkpoint: Tag UI
- [x] `node --check ui/app.js` passes
- [x] Create/edit/reopen preserves `tag_selections` for all three entities
- [x] Selected tags appear in the system prompt

## Phase 4: Group chat room
- [x] Task 8: Make group history scene-scoped and auto-select scene participants.
- [x] Task 9: Harden server group orchestration (mentions, pass, dedupe, cap, named history).
- [x] Task 10: Fix UI response bubbles/status and verify shared timeline behavior.

## Checkpoint: Group chat
- [x] Group test with 3 participants passes
- [x] Shared history includes earlier speaker names
- [x] No duplicate or runaway replies

## Phase 5: Documentation and verification
- [x] Task 11: Update README/help/design docs for sidebar, tags, group chat.
- [x] Task 12: Run full tests, syntax checks, and a live mock-LM-Studio smoke.

## Checkpoint: Complete
- [x] `npm test` passes
- [x] All three note.md features are usable end-to-end
- [x] No existing CRUD/chat behavior regressed
