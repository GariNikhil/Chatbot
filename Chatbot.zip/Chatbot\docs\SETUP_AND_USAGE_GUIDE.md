# Chatbot — Full Setup & Usage Guidelines

This document provides complete, step-by-step instructions for installing, configuring, running, and using Chatbot. For a quick overview, see [README.md](../readme.md) and [run.md](../run.md).

## Table of Contents

- [Overview](#overview)
- [System Requirements](#system-requirements)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running the Application](#running-the-application)
- [Using the Workspace UI](#using-the-workspace-ui)
- [Characters, Scenarios, Scenes & World Cards](#characters-scenarios-scenes--world-cards)
- [Tags System](#tags-system)
- [Group Chat](#group-chat)
- [Memories (Obsidian Integration)](#memories-obsidian-integration)
- [Settings & Help](#settings--help)
- [API Reference](#api-reference)
- [Troubleshooting](#troubleshooting)
- [Development & Testing](#development--testing)
- [Security & Privacy](#security--privacy)

## Overview

Chatbot is a local-first, multi-agent roleplay/chat application where you (Nick) converse with family and friends across different scenes and story scenarios. It uses:

- **LLM Provider** for local LLM inference - supports LM Studio (`http://localhost:1234/v1`) or Ollama (`http://localhost:11434/v1`) with OpenAI-compatible API
- **Chatbot Server** (Node.js) for agent orchestration, prompt assembly, memory management, and API
- **Workspace UI** (static HTML/CSS/JS) for the chat interface
- **Obsidian** (optional but recommended) for durable, human-readable memory storage

Everything runs locally - no data leaves your machine.

## System Requirements

- **OS**: Windows, macOS, or Linux (Windows shortcuts provided via `start.bat`/`stop.bat`)
- **Node.js**: v18+ recommended
- **LM Studio**: Latest version with CLI support (`lms`) recommended for automation
- **Disk Space**: ~100MB for repo + space for models (models vary 2-10GB)
- **RAM**: 8GB minimum, 16GB+ recommended depending on model
- **Obsidian**: Optional, for viewing/editing memories in a nice UI

## Project Structure

```
Chatbot/
├── docs/                    # Documentation (PRD, PLAN, DESIGN, etc.)
├── ui/                      # Workspace chat UI (static HTML/CSS/JS)
├── server/                  # Local API server
├── house/                   # Content/data
│   ├── organization.yaml    # Human-readable manifest (not read at runtime)
│   ├── characters/          # Agent definitions (runtime source of truth)
│   ├── scenarios/           # Story foundations
│   ├── scenes/              # Chapters/locations
│   ├── world cards/         # World/location/genre cards
│   └── tags.yaml            # Canonical tag catalog
├── workspace/               # Runtime data (gitignored)
├── .opencode/               # OpenCode state (gitignored)
├── opencode.json            # OpenCode config
├── .env.example             # Environment template
├── start.bat                # Windows automation script
├── stop.bat                 # Windows stop script
├── readme.md                # Quick overview
└── run.md                   # Quick run instructions
```

## Installation

### 1. Clone the Repository

```bash
git clone <repo-url>
cd Chatbot
```

Or download and extract to any local folder (the repo is path-independent).

### 2. Install LM Studio

1. Download [LM Studio](https://lmstudio.ai/) for your platform
2. Install and launch it
3. Download a model (recommended: `qwen3-4b` or similar)
4. (Optional but recommended) Install the LM Studio CLI `lms` - it's included with recent versions

### 3. Configure Environment

```bash
# Copy the example env file
cp .env.example .env
```

Edit `.env` as needed (see [Configuration](#configuration) section).

### 4. Install Server Dependencies

```bash
cd server
npm install
cd ..
```

## Configuration

### Environment Variables (.env)

| Variable | Default | Description |
|----------|---------|-------------|
| `HOST` | `127.0.0.1` | Server bind address. Use `0.0.0.0` only for LAN access (not recommended) |
| `PORT` | `3001` | Server port |
| `LLM_PROVIDER` | `lmstudio` | LLM provider: `lmstudio` or `ollama` |
| `LLM_BASE_URL` | varies | Provider API endpoint. LM Studio: `http://127.0.0.1:1234/v1`, Ollama: `http://127.0.0.1:11434/v1` |
| `LLM_MODEL` | `local-model` | Default model name. Ollama uses tags like `qwen3:4b` |
| `LMSTUDIO_BASE_URL` | `http://127.0.0.1:1234/v1` | LM Studio API endpoint (backwards compat) |
| `OLLAMA_BASE_URL` | `http://127.0.0.1:11434/v1` | Ollama API endpoint |
| `LMSTUDIO_MODEL` | `local-model` | LM Studio model (backwards compat) |
| `OLLAMA_MODEL` | - | Ollama model name |
| `OBSIDIAN_VAULT_PATH` | (auto-detected) | Path to Obsidian vault for memories. Defaults to `workspace/memory/Chatbot/Memories` |
| `MEMORY_ENABLED` | `true` | Enable/disable memory writing |

### OpenCode Configuration (opencode.json)

```json
{
  "$schema": "https://opencode.ai/config.json",
  "username": "Nick",
  "providers": {
    "lmstudio": {
      "settings": {
        "baseURL": "http://localhost:1234/v1"
      }
    }
  }
}
```

This configures OpenCode to use your local provider. For Ollama, change the baseURL to `http://localhost:11434/v1` or use Ollama's provider config.

## Running the Application

### Option 1: Windows Automated (Easiest)

Double-click `start.bat` from the repository root. It will:
1. Check for LM Studio CLI (`lms`), start LM Studio server on port 1234 if needed (if using LM Studio)
2. Load model `qwen3-4b` (change in script if desired)
3. Start the Chatbot server on port 3001 if not running
4. Open the workspace UI in your default browser

For Ollama, ensure `ollama serve` is running before starting the server. To stop: Use **Settings ▸ End session** in the UI, or double-click `stop.bat`.

### Option 2: Manual Start

#### Start LLM Provider

**LM Studio:**
```bash
# Using CLI
lms server start
lms load qwen3-4b

# Or use the LM Studio GUI: Developer tab > Start Server
```
Verify at `http://127.0.0.1:1234/v1/models`

**Ollama:**
```bash
# Start Ollama server
ollama serve

# Pull a model (in another terminal)
ollama pull qwen3:4b
# or ollama pull llama3.1:8b, mistral, etc.
```
Verify at `http://127.0.0.1:11434/v1/models` or `ollama list`

#### Start Chatbot Server
```bash
cd server
npm start
```

Server will be at `http://127.0.0.1:3001`. Check health at `http://127.0.0.1:3001/health`.

#### Open UI
Navigate to `http://127.0.0.1:3001` in your browser.

## Using the Workspace UI

### Main Interface

1. **Sidebar** (left): Contains Agents panel, Scene selector (grouped by scenario), and Settings menu
2. **Chat Area** (center): Messages, chapter switcher (when in a scenario), composer
3. **Header**: Toggle sidebar with `☰` button (preference remembered)

### Starting a Conversation

1. **Select an Agent**: Click an agent from the Agents panel in the sidebar
2. **Select a Scene** (optional): Choose a scene from the Scene selector. Only participants of that scene are selectable
3. **Type a Message**: Use the composer at the bottom and press Enter or click Send
4. **Receive Response**: Replies stream in real-time from LM Studio

### Chapter Switching (Scenarios)

If you're in a scene linked to a scenario:
- The **Chapter Bar** appears above messages showing all chapters in that scenario
- Click any chapter to switch - keeps scenario foundation but loads chapter-specific context
- Each chapter has its own conversation history and memories

### Model Selection

- Use the model dropdown in the composer to select which loaded model to use
- If your LLM provider is offline, you'll see a red banner with setup instructions
- Placeholder `local-model` auto-resolves to the first loaded model from your provider

## Characters, Scenarios, Scenes & World Cards

### Characters

Characters are defined in `house/characters/<nickname>.yaml`. They're the runtime source of truth.

**Via UI (Settings ▸ Characters):**
- Create new character with nickname, gender, age (18-120), personality, appearance, role
- Edit existing characters
- Delete characters (with confirmation) - cleans up scene references
- Add roleplay fields: background, speech_style, motivations, relationship, behavior_rules
- Assign tags via the tag picker

**Via Files:**
Create `house/characters/alex.yaml`:
```yaml
nickname: "Alex"
gender: "male"
age: 19
personality: "Energetic gamer, tech-curious"
appearance: "5'9\", hoodies, gaming headset"
role: "sibling"
system_prompt: "You are Alex, an energetic 19-year-old gamer..."
memory_enabled: true
tag_selections:
  personality: [personality.playful]
  roles: [roles.sibling]
```

### Scenarios (Stories)

Scenarios are whole stories spanning multiple chapters. Define in `house/scenarios/<key>.yaml` or via **Settings ▸ Scenarios**.

```yaml
name: "The Arranged Marriage"
description: "A story about family expectations and growing connections"
premise: "How the story begins and what led here"
relationship_dynamics: "How relationships evolve"
central_conflict: "Core tension driving the story"
narrative_direction: "Where the story is heading"
background: "Facts that remain true across scenes"
long_term_objectives: "Goals characters are working toward"
participants: ["Nick", "Priya", "Mom", "Dad"]
world_card: "Modern City"
tag_selections:
  story_genres: [story_genres.romance, story_genres.drama]
```

**Managing scenarios:**
- Create in Settings ▸ Scenarios
- Link/unlink chapters by checking scenes or using "Include all scenes"
- Renaming a scenario repoints linked scenes
- Deleting a scenario unlinks scenes (doesn't delete them)

### Scenes (Chapters)

Scenes are individual chapters/locations. Define in `house/scenes/<key>.yaml` or via **Settings ▸ Scenes**.

```yaml
name: "Living Room Evening"
description: "Cozy evening by the fireplace"
participants: ["Mom", "Dad", "Nick"]
location: "Living Room"
world_card: null  # or card name
scenario: the_arranged_marriage  # optional, omit for standalone
tag_selections:
  story_genres: [story_genres.slice_of_life]
  conversation_mood: [conversation_mood.comfort]
```

**Notes:**
- Scenes resolve by file key or display name
- Only scene participants can chat in that scene
- Linked to scenario = inherits scenario foundation + world card
- Standalone scenes = no scenario context

### World Cards

World cards modify tone/setting. Define in `house/world cards/<name>.yaml` or via **Settings ▸ World Cards**.

```yaml
name: "Rainy Evening"
type: "world"  # world | location_shift | genre
description: "It's raining outside; mood is cozy and introspective"
active: false
time_period: "Present day"
tag_selections:
  story_genres: [story_genres.romance]
```

Toggle active cards via **Settings ▸ World Cards**. Active cards are injected into prompts for new messages.

## Tags System

Tags are managed in `house/tags.yaml` and provide structured categorization.

**Categories:** character, scenario, scene, card (specified by `applies_to`)

**Usage:**
- Each entity (character/scenario/scene/card) has a tag picker in its form
- Selections saved as stable IDs (`tag_selections: {category: [category.tag, ...]}`)
- Scenario tags go in scenario block, scene/card tags in their blocks, character tags become "Character Traits"
- Deleted/unavailable tags preserved in YAML but shown as removable "Unavailable" chips
- Clearing a tag never edits text description fields

## Group Chat

Talk to multiple characters simultaneously in one scene.

**Enable:**
1. Select a scene with multiple participants
2. In the Agents panel, enable **Group chat**
3. All AI participants of the scene become available
4. Send one message - characters reply in sequence

**Behavior:**
- Single shared timeline per scene (`group::<sceneKey>`)
- Mentioned characters (`@Name`) reply first
- Empty replies, `[PASS]`, and duplicates are skipped
- Maximum 8 responses per turn
- Switching participants doesn't split history
- History is shared across all participants in the room

## Memories (Obsidian Integration)

Memories create durable, long-term character recollection.

### Storage Structure

**For scenarios:**
```
<Vault>/Chatbot/Memories/scenarios/<scenarioKey>/<sceneKey>/<characterKey>/<date>.md
```

**For standalone/free chat:**
```
<Vault>/Chatbot/Memories/standalone/<sceneKey>/<characterKey>/<date>.md
```

**Legacy (still supported):**
```
<Vault>/Chatbot/Memories/<characterKey>/<date>.md
```

### Memory Format

Each file contains frontmatter + conversation:
```yaml
---
character: Mom
scenario: The Arranged Marriage
scenario_key: the_arranged_marriage
scene: Living Room Evening
scene_key: living_room_evening
timestamp: 2026-10-28T10:30:00Z
importance: 7
---
**Nick:** Hello Mom, how are you?

**Mom:** I'm doing well dear, how about you?
```

### Retrieval

- Before each response, server retrieves newest exchanges for the **same character and exact scene**
- Free chat only sees free-chat memories (scenes don't leak)
- Scenario provides persistent context but NOT shared scene memory
- Each chapter retrieves only its own exchanges

### Managing Memories

**Via UI (Settings ▸ Memories):**
- Browse grouped by Scenario → Chapter → Character
- View individual memory files
- Delete memories (deletes the file)
- Legacy files appear under Standalone scenes or Mixed scenes

**Via API:**
- `GET /memories` - List all memories grouped
- `DELETE /memories/:path` - Delete by vault-relative path
- `DELETE /memories/:character/:date` - Delete legacy format

### Configuration

Set vault path in `.env`:
```env
OBSIDIAN_VAULT_PATH=C:/Users/YourName/Documents/Obsidian/Vault
```

If not set, defaults to `workspace/memory/Chatbot/Memories`. Vault write failures never block replies - they're logged.

## Settings & Help

Access via the **⚙ Settings** button in the lower-left corner of the sidebar.

### Settings Menu Options

| Option | Purpose |
|--------|---------|
| **Scenarios** | Create/edit stories, link chapters |
| **Scenes** | Create/edit chapters, assign participants, link to scenarios |
| **Characters** | Create/edit/delete agents |
| **World Cards** | Create/edit world cards, toggle active state |
| **Memories** | Browse and delete memories |
| **Help** | Open help modal with setup/status info |
| **End session** | Stop the Chatbot server |

### Help Modal

Shows:
- Quick start instructions
- Chatting tips
- Tags explanation
- LM Studio CLI commands
- Scenarios & scenes explanation
- Live server status (backend URL, server running, LM Studio connection + loaded models)

## API Reference

Server runs on `http://127.0.0.1:3001` by default.

### Core Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/` | Serve workspace UI |
| `GET` | `/health` | Server + LM Studio status |
| `GET` | `/agents` | List all characters |
| `GET` | `/characters/:key` | Full character definition |
| `GET` | `/scenes` | List scenes |
| `GET` | `/scenarios` | List scenarios |
| `GET` | `/cards` | List world cards |
| `GET` | `/tags` | Tag catalog (`?target=character\|scenario\|scene\|card`) |
| `GET` | `/models` | Loaded LM Studio models |

### CRUD Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/characters` | Create character (age 18-120, required fields) |
| `PUT` | `/characters/:key` | Update/rename character |
| `DELETE` | `/characters/:key` | Delete character, clean scene refs |
| `POST` | `/scenarios` | Create scenario (optional `scenes` to link) |
| `PUT` | `/scenarios/:key` | Update/rename, optional `scenes` to reassign |
| `DELETE` | `/scenarios/:key` | Delete scenario, unlink scenes |
| `POST` | `/scenes` | Create scene (name + participants required) |
| `PUT` | `/scenes/:key` | Update/rename scene |
| `DELETE` | `/scenes/:key` | Delete scene |
| `POST` | `/cards` | Create world card |
| `PUT` | `/cards/:key` | Update card |
| `PATCH` | `/cards/:key` | Set active state `{"active": true/false}` |

### Chat & Memory

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/chat` | Stream reply (NDJSON: `delta` → `done`). Body: `agentNickname` or `characterNicknames`, `sceneName`, `message`, optional `model`, `history`, `activeCards` |
| `GET` | `/memories` | List memories grouped |
| `DELETE` | `/memories/:path` | Delete memory by vault-relative path |
| `DELETE` | `/memories/:char/:date` | Delete legacy memory |
| `POST` | `/shutdown` | Stop server (used by Settings ▸ End session) |

### API Notes

- Write endpoints require `Content-Type: application/json` (415 otherwise)
- Body must be a JSON object (400 otherwise)
- Body size limit enforced (413 if too large)
- Placeholder model `local-model` resolves to first loaded LM Studio model
- Group chat: send `characterNicknames` array instead of `agentNickname`
- Scene resolved by file key or display name
- Chat errors from LM Studio show helpful messages with CLI commands

## Troubleshooting

### LLM Provider Issues

**Provider Offline in UI**

*LM Studio:*
```bash
# Start server
lms server start

# Load a model
lms load qwen3-4b

# Check status
lms server status
```
Or use LM Studio GUI: Developer → Start Server, load model from dropdown.

*Ollama:*
```bash
# Start server
ollama serve

# Pull a model
ollama pull qwen3:4b

# List models
ollama list
```

**No models showing**
- Ensure model is actually loaded/running (LM Studio: loaded, Ollama: pulled)
- Check endpoint: `curl http://127.0.0.1:1234/v1/models` (LM Studio) or `curl http://127.0.0.1:11434/v1/models` (Ollama)
- Verify `LLM_PROVIDER` and `LLM_BASE_URL` in `.env` match your setup

### Server Issues

**Port 3001 already in use**
```bash
# Windows
stop.bat

# Or manually kill process
netstat -ano | findstr :3001
taskkill /PID <pid> /F
```

**Server won't start**
- Check Node.js installed: `node --version`
- Reinstall dependencies: `cd server && npm install`
- Check `.env` for syntax errors
- Look for errors in terminal output

**Can't access UI**
- Verify server running: `http://127.0.0.1:3001/health`
- Check firewall isn't blocking localhost
- Try different browser
- Ensure not binding to wrong host

### Chat Issues

**Agent not responding**
- Check your LLM provider is running and model is available
- Check health endpoint shows provider reachable
- Look at server terminal for errors
- Try shorter message or different model

**Wrong agent personality**
- Verify character YAML in `house/characters/`
- Check `system_prompt` is set
- Ensure scene participants include the agent
- Scenario/scene context might influence responses

**Memories not saving**
- Check `OBSIDIAN_VAULT_PATH` is correct and writable
- Verify directory permissions
- Look for errors in server logs
- Memory writes are best-effort and won't block replies

### UI Issues

**Sidebar won't show/hide**
- Click `☰` button in header
- Clear localStorage if stuck: open DevTools → Application → LocalStorage → clear `aihouse_sidebar_hidden`
- Refresh page

**Scene not showing participants**
- Check scene's `participants` array in `house/scenes/*.yaml`
- Ensure character files exist for those nicknames
- Character keys are case-insensitive but nicknames must match

**Tags not loading**
- Verify `house/tags.yaml` exists and is valid YAML
- Check browser console for errors
- Tags are loaded from server `/tags` endpoint

## Development & Testing

### Running Tests

```bash
cd server
npm test
```

Tests cover character/scene loading, CRUD operations, chat flow, etc.

### Project Phases

See [docs/PHASES.md](PHASES.md) for development progress:
- Phase 0: Discovery & Scaffolding ✓
- Phase 1: Core Chat Runtime (in progress)
- Phase 2: Scenes & Scenarios ✓
- Phase 3: Durable Memory ✓
- Phase 4: World Cards & Location Shifts
- Phase 5: Character Creation & Management
- Phase 6: Polish, Testing & Release

### Contributing

See [CONTRIBUTING.md](../CONTRIBUTING.md) and [docs/RULES.md](RULES.md) for guidelines.

### Code Structure

- `server/index.js` - Main server, routes, API endpoints
- `server/lib/` - Utilities (characters, scenes, scenarios, memory, tags, etc.)
- `ui/app.js` - Frontend logic
- `ui/index.html` - UI structure
- `ui/styles.css` - Styling

## Security & Privacy

- **Local-first**: All LLM calls go to local providers (LM Studio or Ollama), no external API calls
- **No authentication**: Single-user local application
- **Bound to localhost**: Server binds to `127.0.0.1` by default
- **File writes protected**: JSON body validation, Content-Type checks, size limits
- **Git-friendly**: Character/scenario/scene data in plain YAML/Markdown
- **No telemetry**: No tracking or analytics

**Warning**: Only bind to `0.0.0.0` (LAN) if you understand the security implications. The server has no authentication.

## Additional Resources

- [README.md](../readme.md) - Quick overview
- [run.md](../run.md) - Quick start
- [docs/PRD.md](PRD.md) - Product requirements
- [docs/DESIGN.md](DESIGN.md) - System architecture
- [docs/API.md](API.md) - Detailed API docs (if exists)
- [LM Studio Docs](https://lmstudio.ai/docs) - LM Studio documentation
- [Ollama Docs](https://github.com/ollama/ollama) - Ollama documentation
- [Obsidian](https://obsidian.md/) - Note-taking app for viewing memories

---

**Need help?** Use **Settings ▸ Help** in the UI for live server/provider status, or check the troubleshooting section above.
