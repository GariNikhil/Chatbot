# Chatbot — Project Rules & Conventions

## 1. General Principles

- **Local-first**: No cloud LLM APIs. All inference runs via LM Studio on `http://127.0.0.1:1234/v1`.
- **Config-driven**: Characters, scenes, cards, and organization are defined in YAML/Markdown. No hardcoded agents.
- **Human-in-the-loop**: Nick tests and approves agents before autonomous mode is enabled.
- **Git-friendly**: All configuration is plain text (YAML/Markdown) for version control.

## 2. File Naming Conventions

| File Type | Location | Naming Pattern | Example |
|-----------|----------|----------------|---------|
| Organization | `house/` | `organization.yaml` (descriptive manifest) | `organization.yaml` |
| Character | `house/characters/` | `<nickname>.yaml` (lowercase, slugified) | `house/characters/mom.yaml` |
| Scene | `house/scenes/` | `<name>.yaml` (lowercase, slugified) | `house/scenes/living_room_evening.yaml` |
| Scenario | `house/scenarios/` | `<name>.yaml` (lowercase, slugified) | `house/scenarios/the_arranged_marriage.yaml` |
| Card | `house/world cards/` | `<name>.yaml` (lowercase, spaces → underscores) | `house/world cards/rainy_evening.yaml` |
| Memory | Obsidian vault | `<scenario>/<scene>/<character>/<YYYY-MM-DD>.md` (or `standalone/<scene>/<character>/`) | `Memories/scenarios/the_arranged_marriage/the_first_meeting/mom/2026-10-24.md` |
| Docs | `docs/` | `UPPER_CASE.md` | `docs/PRD.md` |

## 3. YAML Field Conventions

- Use snake_case for keys: `nickname`, `memory_enabled`, `system_prompt`, `world_card`.
- Required character fields: `nickname`, `gender`, `age`, `personality`, `appearance`.
- Optional character fields: `role`, `system_prompt`, `memory_enabled`,
  `background`, `speech_style`, `motivations`, `relationship`, `behavior_rules`.
- Boolean fields: use `true`/`false`, not `yes`/`no` or `1`/`0`.
- Age: integer from 18 to 120.
- Unknown extra scenario/scene/card fields are preserved and included in prompts.
- Scenario-level tags and scene-level tags are stored separately; link a chapter
  with a scene's optional `scenario` field.

## 4. Commit Message Convention

Use conventional commits:

```
<type>(<scope>): <description>

[optional body]
```

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `style`.

Examples:
- `feat(characters): add Mom character definition`
- `fix(chat): handle LM Studio connection timeout`
- `docs(PRD): add memory requirements`
- `chore(repo): add .gitignore`

## 5. Branch Naming

```
<type>/<short-description>
```

Examples: `feat/core-chat`, `fix/memory-retrieval`, `docs/roadmap`

## 6. Code & Config Standards

- All YAML files must validate against the defined schema before commit.
- Character `system_prompt` must be written in second person ("You are...").
- Scene descriptions should be evocative but concise (1–2 sentences).
- No secrets, API keys, or personal data committed to the repo.
- `.env` files are gitignored; use `.env.example` for template.

## 7. Testing Rules

- Every new feature must have at least one manual test case documented in `docs/TASKS.md`.
- Chat functionality must be tested with all defined agents before marking Phase 1 complete.
- Memory retrieval must be tested across at least 3 separate sessions before Phase 3 complete.

## 8. Documentation Rules

- When behavior changes, update `docs/PRD.md` and `docs/DESIGN.md` in the same PR.
- New configuration options must be documented in `docs/DESIGN.md` with a YAML example.
- The README must always reflect the current install and run instructions.

## 9. Definition of Done (per task)

- [ ] Code/config written and reviewed
- [ ] Tests pass (manual or automated)
- [ ] Docs updated (if applicable)
- [ ] Committed with conventional commit message
- [ ] Demoed to Nick (for user-facing features)

## 10. Prohibited Practices

- ❌ No hardcoded agent responses (all generation via LM Studio)
- ❌ No cloud LLM API calls (OpenAI, Anthropic, etc.)
- ❌ No committed secrets or `.env` files with real values
- ❌ No runtime behaviour added to `house/organization.yaml` — agent data belongs in `house/characters/`
