# Chatbot — System Design

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        workspace UI                         │
│              (Visual Multi-Agent Office / Hive)             │
└─────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────┐
│                    Chatbot server (Node.js)                │
│  • Agent orchestration                                      │
│  • System prompt injection                                  │
│  • Scenario, scene & memory context assembly                │
└─────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────┐
│              LLM Provider (LM Studio or Ollama)             │
│       http://localhost:1234/v1 or 11434/v1 (OpenAI-compat)  │
└─────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────┐
│                     Obsidian Vault                          │
│         (Durable Markdown-based memory store)               │
└─────────────────────────────────────────────────────────────┘
```

## 2. Component Responsibilities

| Component          | Responsibility                                                                                     |
| ------------------ | -------------------------------------------------------------------------------------------------- |
| **workspace**       | Frontend UI: chat interface, character/scene selection, card activation, agent directory           |
| **Chatbot server**| Agent runtime: loads characters, builds prompts, streams LLM responses, persists memories            |
| **LLM Provider**    | Local LLM inference server (LM Studio or Ollama); exposes OpenAI-compatible chat completions API |
| **Obsidian**       | Durable knowledge base: stores character memories, scene notes, world state as Markdown            |

## 3. Data Flow

### 3.1 Chat Request Flow

1. Nick types a message in the workspace UI.
2. UI sends message + active scene + selected agent to the Chatbot server.
3. The server loads:
   - Agent definition from `house/characters/<nickname>.yaml`
   - Scenario foundation from `house/scenarios/<scenario>.yaml` when the scene
     links to one
   - Scene context from `house/scenes/<scene>.yaml` (by file key or display name)
   - Relevant memories from the Obsidian vault, scoped to that exact scene
4. The server assembles the system prompt in this order: agent personality and
   safety instructions → scenario foundation (premise, relationships, tags,
   cast) → character traits → active/scenario/scene world cards → current scene
   (location, description, tags, participants) → memories.
5. The server calls LM Studio `/v1/chat/completions` with the assembled prompt.
6. LM Studio streams the agent's in-character reply.
7. The server writes the exchange to Obsidian (best-effort) and streams the reply to the UI.
   The browser keeps its own per-agent/scene history in `localStorage`.

### 3.2 Scene Switch Flow

1. User switches scene either from the sidebar selector (grouped by scenario) or
   from the chapter bar above the messages, which lists every chapter of the
   active scenario.
2. The server loads the scene definition and its participants.
3. Only agents listed in `scene.participants` are available for chat in that scene.
4. The new scene supplies its own immediate context, while a linked scenario's
   premise, relationships, tags, and world card continue to apply.
5. Conversation history and memories are keyed by the exact scene, so switching
   chapters never merges their timelines.

## 4. Configuration Files

### 4.1 `house/organization.yaml` (descriptive manifest)

This file documents the intended hierarchy for humans. It is **not read by the
runtime**; `house/characters/*.yaml` is the source of truth for agents, roles,
and system prompts. Keep the manifest in sync when editing docs, but adding a
character file is what makes an agent appear in the UI.

```yaml
house:
  name: "Chatbot"
  owner: "Nick"  # {{user}}
  hierarchy:
    - role: "parent"
      members: ["Mom", "Dad"]
    - role: "sibling"
      members: ["Alex", "Soniya"]
    - role: "friend"
      members: ["Jordan", "Priya"]

agents:
  - nickname: "Mom"
    gender: "female"
    age: 45
    personality: "Warm, caring, slightly overprotective, loves cooking"
    appearance: "5'6\", brown hair, always wears an apron"
    role: "parent"
    system_prompt: "You are Mom, a warm and caring parent..."
    memory_enabled: true

  - nickname: "Nick"
    gender: "male"
    age: 28
    personality: "Curious, sarcastic, loves technology"
    appearance: "5'10\", casual t-shirts and jeans"
    role: "user"
    system_prompt: "You are Nick, the main user character..."
    memory_enabled: false
```

### 4.2 Character File (`house/characters/<nickname>.yaml`)

```yaml
nickname: "Mom"
gender: "female"
age: 45
personality: "Warm, caring, slightly overprotective"
appearance: "5'6\", brown hair, apron"
role: "parent"
system_prompt: "You are Mom..."
memory_enabled: true
# Optional roleplay fields (also accepted by the API and preserved on edits):
background: "Raised the family in this house."
speech_style: "Warm, teasing, direct."
motivations: "Keep everyone fed and talking."
relationship: "Nick's mother."
behavior_rules: "Never breaks character."
# Optional structured tags (ids come from house/tags.yaml):
tag_selections:
  personality: [personality.caring, personality.playful]
  roles: [roles.parent]
  emotional_traits: [emotional_traits.protective]
```

Ages must be integers from 18 to 120. Characters with Unicode names are stored
under a slugified file key (for example `José` → `jose.yaml`).

### 4.3 Scenario File (`house/scenarios/<key>.yaml`)

A scenario is the whole story; scenes are chapters inside it. Scenarios are
loaded at runtime and can be managed from **Settings ▸ Scenarios**.

```yaml
name: "The Arranged Marriage"
description: "The overall story in 2–4 sentences."
premise: "How the story begins and what led here."
relationship_dynamics: "How the central relationship starts and evolves."
central_conflict: "The core tension driving the story."
narrative_direction: "Where the story is heading."
background: "Facts that remain true across scenes."
long_term_objectives: "What the characters are working toward."
opening_message: "Optional scene-setting text."
participants: ["Nick", "Priya", "Mom", "Dad"]
world_card: "The City of Little Moments"
tag_selections:
  story_genres: [story_genres.romance, story_genres.drama]
  relationship_dynamics: [relationship_dynamics.arranged_marriage]
  world_settings: [world_settings.modern_city]
```

Story-wide fields beyond the core keys are preserved and included in the
scenario prompt block. Renaming a scenario repoints its linked scenes; deleting
it unlinks those scenes instead of deleting them. A scenario's `world_card` is
always applied to chapters linked to that scenario. Older scenario files with
sparse fields or non-slug filenames still load; API/UI keys are normalized.

A scenario can claim several chapters in one step. **Settings ▸ Scenarios** lists
every scene with an **Include all scenes** toggle, and `POST/PUT /scenarios`
accepts an optional transient `scenes: [<key or name>, …]` list. The canonical
link still lives on each scene's `scenario` field, so the list is never written
into scenario YAML: listed chapters are linked, linked chapters left out become
standalone, and omitting `scenes` leaves membership unchanged. While chatting,
the chapter bar above the messages lists the chapters of the active scenario so
the user can jump from one scene to another without opening settings.

### 4.4 Scene File (`house/scenes/<key>.yaml`)

```yaml
name: "Living Room Evening"
description: "Cozy evening in the living room, fireplace lit"
participants: ["Mom", "Dad", "Nick"]
location: "Living Room"
world_card: null
scenario: the_arranged_marriage # optional; omit for a standalone scene
# Extra fields are optional and included in the prompt:
tags: [family, evening]
interactions: [Board games, old stories]
# Structured tags (ids come from house/tags.yaml):
tag_selections:
  story_genres: [story_genres.slice_of_life]
  conversation_mood: [conversation_mood.comfort]
```

Scenes resolve by file key first and display name second, so
`the_corner_cafe` and `The Corner Café` both address the same file. A scene's
`world_card` is always included in the prompt, in addition to any active cards.
When `scenario` is set, the scenario foundation and its world card are included
before the scene block. Scenes without `scenario` remain standalone and behave
exactly as before.

### 4.5 World Card (`house/world cards/<name>.yaml`)

```yaml
name: "Rainy Evening"
type: "world" # world | location_shift | genre
description: "It's raining outside; mood is cozy and introspective"
active: false
# Any additional lore fields are preserved and included in the prompt:
time_period: "Present day"
# Structured tags (ids come from house/tags.yaml):
tag_selections:
  story_genres: [story_genres.romance]
  world_settings: [world_settings.small_town]
```

### 4.6 Tag Catalog (`house/tags.yaml`)

The single canonical tag source. Each category declares an `id`, `label`,
`applies_to` list (`character`, `scenario`, `scene`, `card`), an optional
`multiple: false` for single-select categories, and its tags. Stored selections
use stable `<category>.<tag>` ids under a `tag_selections` map on the character,
scenario, scene, or card. Labels are display-only, so renaming a label never
breaks saved data. Selections for tags removed from the catalog are preserved on
disk, ignored by prompt assembly, and shown as removable "Unavailable" chips in
the UI. Character tags become a `## Character Traits` prompt block; scenario
tags join the scenario block, and scene/card tags join their own context blocks,
all filtered by `applies_to`.

## 5. Memory Model

- **Short-term**: Conversation history held in the browser per agent + scene
  (`localStorage`) and sent to the server with each turn (up to 50 messages).
  Group chat uses one room per scene (`group::<sceneKey>`, or `group::free`),
  so adding or removing participants keeps the same shared timeline.
- **Long-term**: Each exchange is appended to a Markdown file under the story
  hierarchy, so memories belong to a book → chapter → character rather than to
  a character alone:
  - Scenario chapter:
    `<vault>/Chatbot/Memories/scenarios/<scenarioKey>/<sceneKey>/<characterKey>/<date>.md`
  - Standalone scene (including free chat):
    `<vault>/Chatbot/Memories/standalone/<sceneKey>/<characterKey>/<date>.md`
  - Legacy vaults keep working: `<vault>/Chatbot/Memories/<characterKey>/<date>.md`
    is still read, listed under **Standalone scenes**, and deletable.
  - Every exchange has its own frontmatter block (`character`, `scenario`,
    `scenario_key`, `scene`, `scene_key`, `timestamp`, `importance`) followed by
    the user/assistant text.
  - A vault write failure never fails a completed reply; it is logged instead.
- **Dashboard**: `GET /memories` returns scenarios → scenes → characters, with
  each entry carrying its vault-relative `path` for deletion. Legacy files are
  grouped by the scene recorded in their frontmatter; multi-scene legacy files
  appear under **Mixed scenes**.
- **Retrieval**: Before each response the server replays the newest exchanges
  for the same character **and exact scene name**. Free chat (`scene = ""`) only
  sees free-chat memories, so scenes never leak context into each other. A
  scenario provides persistent story context, not shared scene memory: each
  chapter still retrieves only its own exchanges.

## 6. Security & Privacy

- All LLM calls go to local LM Studio; no data leaves the machine.
- Character and memory files are plain text/YAML/Markdown, suitable for git version control.
- The server binds to `127.0.0.1` by default. `HOST=0.0.0.0` is an explicit
  opt-in to LAN access.
- Write endpoints require `Content-Type: application/json` (otherwise `415`),
  reject non-object JSON, and cap body size (`413`). This narrows the CSRF
  surface of a local server that writes files.
- No authentication required (single-user local app).
- No external API keys needed.

## 7. Extension Points

- New agents: Add a YAML file to `house/characters/` (or use the UI form, which
  calls `POST /characters`). Optionally update `house/organization.yaml` so the
  manifest stays accurate — the server does not read it.
- New scenarios: Add a YAML file to `house/scenarios/` or create one in
  **Settings ▸ Scenarios**. Link chapters with a scene's `scenario` field.
- New scenes: Add a YAML file to `house/scenes/`.
- New cards: Add a YAML file to `house/world cards/`.
- New memory sources: Extend the server's retrieval logic to read additional
  Obsidian folders.

## 8. HTTP API

The Chatbot server exposes a small HTTP surface (default
`http://127.0.0.1:3001`; override with `HOST`/`PORT`):

| Method | Path                | Purpose                                                             |
| ------ | ------------------- | ------------------------------------------------------------------- |
| GET    | `/`                 | workspace UI (static files from `ui/`)                         |
| GET    | `/agents`           | List all characters from `house/characters/`                        |
| GET    | `/characters/<key>` | Full character definition (including `system_prompt`)               |
| GET    | `/scenes`           | List scenes with key, name, description, participants, scenario link |
| GET    | `/scenarios`        | List story foundations (premise extras, participants, world card)   |
| GET    | `/cards`            | List world/location/genre cards with persisted `active` state       |
| GET    | `/tags`             | Canonical tag catalog; `?target=character\|scenario\|scene\|card` filters |
| POST   | `/cards`            | Create a card (extra lore fields are preserved)                     |
| PUT    | `/cards/<key>`      | Update a card (name, description, type, active, tags, lore fields)  |
| PATCH  | `/cards/<key>`      | Set card activation state (`{"active": true}`) — saved to YAML      |
| POST   | `/chat`             | Stream a reply (NDJSON: `delta` → `done`) for agent+scene+message   |
| GET    | `/models`           | Models currently loaded in LM Studio; `503` when offline            |
| POST   | `/scenarios`        | Create a scenario; optional `scenes` list links chapters in bulk   |
| PUT    | `/scenarios/<key>`  | Update/rename a scenario; optional `scenes` list reassigns chapters |
| DELETE | `/scenarios/<key>`  | Delete a scenario; linked scenes become standalone                  |
| POST   | `/scenes`           | Create a scene (name + participants required; optional `scenario`)  |
| PUT    | `/scenes/<key>`     | Update/rename a scene — including its `participants` and `scenario` |
| DELETE | `/scenes/<key>`     | Delete a scene                                                      |
| GET    | `/memories`         | Vault memories grouped scenario → scene → character                  |
| DELETE | `/memories/<path>`  | Delete one memory by vault-relative path                            |
| DELETE | `/memories/<char>/<date>` | Legacy character-first path; still supported                  |
| POST   | `/characters`       | Create a character (required fields, age 18–120, duplicate check)    |
| PUT    | `/characters/<key>` | Update/rename a character; scenes follow the new nickname            |
| DELETE | `/characters/<key>` | Delete a character and clean up its scene references                 |
| GET    | `/health`           | Server + LM Studio status (`lmStudio.reachable`, models)            |

Write endpoints require `Content-Type: application/json` and a JSON object
body; other media types return `415`, non-objects return `400`, and bodies over
`MAX_BODY_BYTES` return `413`. Chat requests accept `agentNickname`,
`sceneName` (file key or display name), `message`, optional `model`, optional
`history` (up to 50 turns) and optional `activeCards`. A placeholder model id
(`local-model`, the `LMSTUDIO_MODEL` default) resolves to the first model loaded
in LM Studio. When `activeCards` is omitted, the persisted card activation state
(cards with `active: true`) is used. A scene's own `world_card` is always
applied; if the scene links to a scenario, that scenario's foundation and
`world_card` are applied as well. Sending `characterNicknames` instead of
`agentNickname` runs a group
turn: every listed AI character replies in sequence against one shared history,
mentioned characters go first, `[PASS]` and duplicate replies are skipped, and a
hard cap limits the number of generated replies. The scene must include the
agent in its `participants` list
(case-insensitive, canonicalized to the character's nickname). Network errors
reaching LM Studio surface as a `LmStudioOfflineError` and stream a friendly
error line with the `lms server start` / `lms load <model>` remedy.

### 8.1 Start setup

Double-click `start.bat` at the repo root: it starts LM Studio on port 1234
if needed, ensures `qwen3-4b` is loaded, starts the Chatbot server on port
3001 unless already running, and opens the UI. `stop.bat` stops the server
(port 3001) for restarts.
