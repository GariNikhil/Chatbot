# Chatbot — Project Plan

## 1. Purpose

This document defines the execution plan for building Chatbot: a local, hierarchical multi-agent chat application where Nick ({{user}}) converses with family and friend agents across scenes and scenarios.

## 2. Guiding Principles

| Principle | Meaning |
|-----------|---------|
| Local-first | Everything runs on the user's machine via LM Studio + the Chatbot server + Obsidian. |
| Config-driven | Characters, scenes, and organization are defined in YAML/Markdown, not hardcoded. |
| Incremental | Ship in thin, verifiable slices; each phase delivers working functionality. |
| Human-in-the-loop | Nick tests and approves agents before autonomous mode is enabled. |

## 3. High-Level Milestones

| Milestone | Description | Target |
|-----------|-------------|--------|
| M1 — Foundation | Repo structure, docs, `house/organization.yaml`, character schema | Week 1 |
| M2 — Core Chat | Nick ↔ agent chat via the Chatbot server + LM Studio | Week 2–3 |
| M3 — Scenes & Scenarios | Scene/workspace creation, agent-to-scene assignment | Week 4 |
| M4 — Memory | Obsidian integration for durable character memory | Week 5 |
| M5 — World Cards | Location-shift and world card system | Week 6 |
| M6 — Polish & Testing | UI polish via workspace UI, testing, bug fixes | Week 7 |

## 4. Decision Log

| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-10-24 | Stack: local Node.js server + LM Studio + workspace + Obsidian | Local-first requirement; no cloud dependency |
| 2026-10-24 | Config format: YAML for characters/scenes/cards, Markdown for Obsidian memory | Git-friendly, human-editable |
| 2026-10-26 | The repository is path-independent; clone it anywhere | Removes machine-specific install assumptions |
| 2026-10-26 | `house/characters/` is the runtime source of truth; `organization.yaml` is a manifest | Matches the server's loader behaviour |
