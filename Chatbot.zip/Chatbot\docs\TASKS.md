# Chatbot — Task Breakdown

## Phase 0 — Scaffolding & Docs

- [x] T-0.1 Initialize git repo with `.gitignore` (ignore `.opencode/*`,
      `workspace/*`, env files, OS files)
- [x] T-0.2 Create directory structure: `/docs`, `/house`, `/house/characters`,
      `/house/scenes`, `/house/cards`, `/.opencode`, `/workspace`
- [x] T-0.3 Write `docs/PRD.md` (product requirements)
- [x] T-0.4 Write `docs/PLAN.md` (execution plan)
- [x] T-0.5 Write `docs/PHASES.md` (phase breakdown)
- [x] T-0.6 Write `docs/ROADMAP.md` (timeline)
- [x] T-0.7 Write `docs/DESIGN.md` (system architecture)
- [x] T-0.8 Write `docs/TASKS.md` (this file)
- [x] T-0.9 Write `docs/RULES.md` (project conventions)
- [x] T-0.10 Create `house/organization.yaml` with Nick + 3+ agents
- [x] T-0.11 Create initial character files in `house/characters/`
- [x] T-0.12 Create initial scene files in `house/scenes/`

## Phase 1 — Core Chat Runtime

- [x] T-1.1 Configure the Chatbot server to connect to LM Studio at
      `http://127.0.0.1:1234/v1`
- [x] T-1.2 Implement agent loader: reads characters from `house/characters/`
- [x] T-1.3 Implement prompt assembler: agent system_prompt + scene context +
      memory
- [x] T-1.4 Implement chat endpoint: send user message → LM Studio →
      stream reply
- [x] T-1.5 workspace chat UI: agent selection, scene selector, card
      toggles, character management, streaming message history (`ui/`)
- [ ] T-1.6 Test: chat with all defined agents; verify in-character responses
      (live streaming chat through qwen3-4b verified for Mom; repeat for the
      remaining agents via the UI at `http://localhost:3001`)

## Phase 2 — Scenes & Scenarios

- [x] T-2.1 Define scene schema and validation
- [x] T-2.2 Create scene files in `house/scenes/`
- [x] T-2.3 Implement scene loader and active-scene request state
- [x] T-2.4 UI: scene selector dropdown (agents filtered to scene
      participants)
- [x] T-2.5 Inject scene context into agent prompts
- [x] T-2.6 Test: switch scenes; verify agent behavior changes
- [x] T-2.7 UI: per-scene agent selection (toggle agents in/out of the active
      scene; persists via `PUT /scenes/:key`)
- [x] T-2.8 UI: scene manager — create/edit/delete scenes
      (`POST /scenes`, `PUT/DELETE /scenes/:key`)
- [x] T-2.9 Scenario runtime: load `house/scenarios/`, link chapters with
      `scene.scenario`, persist story context across scene switches, separate
      scenario/scene tags, and manage scenarios from Settings ▸ Scenarios
- [x] T-2.10 Bulk chapter assignment: choose all/several scenes in the scenario
      form (`scenes` API list) and switch chapters from the chat chapter bar

## Phase 3 — Durable Memory (Obsidian)

- [x] T-3.1 Configure Obsidian vault path (configurable via env or settings)
- [x] T-3.2 Implement memory writer: save exchanges to Obsidian-compatible
      Markdown
- [x] T-3.3 Implement memory reader: query vault for scene-scoped memories
      before response
- [x] T-3.4 Memory importance scoring (1–10) in the Markdown schema
- [x] T-3.5 Test: memory is read back across calls
- [x] T-3.6 UI: Memories dashboard panel — browse vault memories grouped by
      story → chapter → character (date, importance, preview) and delete entries
      (`GET /memories`, `DELETE /memories/:path`)
- [x] T-3.7 Vaults: memory listing ignores stray files and non-memory vault
      folders (scenes, archives, …)
- [x] T-3.8 Story-first memory storage:
      `scenarios/<story>/<chapter>/<character>/<date>.md` (or
      `standalone/<chapter>/<character>/`), with legacy
      `<character>/<date>.md` files still read and displayed

## Phase 4 — World Cards & Location Shifts

- [x] T-4.1 Define world card and location-shift card schema
- [x] T-4.2 Create card files in `house/cards/`
- [x] T-4.3 Implement card activation/deactivation state — persisted to card
      YAML via `PATCH /cards/:key`; default active cards apply to `/chat`
- [x] T-4.4 UI: card toggle interface in the sidebar
- [x] T-4.5 Inject active cards into agent context
- [x] T-4.6 Test: active cards are included in the assembled prompt

## Phase 5 — Character Management

- [x] T-5.1 UI form: create new character (nickname, gender, age,
      personality, appearance, role)
- [x] T-5.2 Character validation (required fields, age 18–120, duplicate
      nickname check; `409` on duplicates)
- [x] T-5.3 Save new character to `house/characters/` (`POST /characters`)
- [x] T-5.4 UI: edit existing character (`PUT /characters/:key`, rename
      supported)
- [x] T-5.5 UI: delete character with confirmation (`DELETE /characters/:key`)
- [x] T-5.6 Test: create a new character via UI and chat with it (create →
      chat → delete verified in integration tests; live UI walkthrough needs
      LM Studio running)

## Phase 6 — Polish, Testing & Release

- [x] T-6.1 Integrate workspace UI (served from `ui/` at
      `http://localhost:3001/`)
- [x] T-6.2 Error handling: LM Studio offline, missing character file,
      invalid YAML
- [x] T-6.7 UI: Settings menu in the lower-left corner of the dashboard
      with Characters, World Cards, Memories, and Help options
- [x] T-6.3 Unit tests: character loading, scene loading, configuration,
      memory, and streaming
- [x] T-6.4 Integration tests: full chat flow end-to-end against a mock
      LM Studio server (`server/test/integration.test.js`)
- [x] T-6.5 Update README with current install/run instructions
- [x] T-6.6 Final repo cleanup: `.gitignore`, remove temp files, docs review

## Test Status

`npm test` in `server/` runs 42 tests (all passing): configuration parsing,
character/scene/card loading, prompt assembly, Obsidian-style memory,
LM Studio SSE streaming, model discovery, smoke endpoints, and an
end-to-end chat flow with a mock LM Studio. Integration tests run against a
temporary copy of `house/` (`AI_HOUSE_ROOT`) so they never mutate authored
content, and cover character CRUD, scene CRUD, key/display-name/Unicode scene
resolution, extras preservation, delete cleanup, content-type/body limits,
age validation, card tolerance, memory scoping, and card activation.

Remaining manual work: a live UI walkthrough of agent/scene switching and the
create + chat form at `http://127.0.0.1:3001`.
