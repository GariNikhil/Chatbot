# Implementation Plan: note.md Features

## Overview

Implement the three requests in `D:\projects\MNC\note.md` against the existing
Chatbot architecture:

1. A persisted, responsive sidebar expand/collapse toggle.
2. A reusable tag system integrated into character, scene, and world-card
   create/edit forms, persisted to YAML, and injected into the LLM prompt.
3. A scene-scoped group chat room where every participant shares one timeline
   and one conversation history.

The existing stack is reused: static `ui/` HTML/CSS/JS, Node HTTP server,
YAML files under `house/`, and LM Studio via the existing streaming client.

## Architecture Decisions

- **Sidebar state** lives in the existing `Chatbot.ui.v1` localStorage record.
  Desktop uses a grid-column collapse with a CSS transition; mobile turns the
  sidebar into an overlay drawer with a backdrop. One toggle button, one state
  variable.
- **Tag data has one canonical source**: `house/tags.yaml`. Existing free-text
  `tags: [..]` arrays on scene files are legacy author fields and stay
  untouched. Structured selections use a new `tag_selections` mapping
  (`categoryId: [tagId,...]`) so no authored data is rewritten or duplicated.
- **Tag IDs are stable**: `<category_id>.<slug>`; labels are display-only.
  Unknown/deleted IDs are preserved in YAML, ignored by prompts, and shown as
  removable "unavailable" chips in the picker.
- **Only relevant categories appear per entity**, via each category's
  `applies_to` list (`character`, `scene`, `card`).
- **Tags reach the model** through `assembleSystemPrompt`: character tags in a
  `## Character Traits` block, scene/card tags in their existing context blocks.
- **Group chat is one room per scene.** The client conversation key becomes
  `group::<sceneKey>` (or `group::free`), so changing participants does not
  split history. Enabling group mode preselects all AI participants of the
  scene.
- **The server owns group orchestration**: one user turn, each selected
  character gets one chance to reply, explicitly mentioned characters speak
  first, `[PASS]` replies are skipped, duplicate replies are dropped, and a
  hard response cap prevents loops.

## Task List

### Phase 1: Sidebar toggle
- [x] Task 1: Add hamburger toggle, desktop collapse, mobile drawer, persistence, and accessibility.

### Checkpoint: Sidebar
- [x] `node --check ui/app.js` passes
- [x] Toggle state survives reload; layout has no overlap at desktop/mobile widths

### Phase 2: Tag foundation
- [x] Task 2: Create canonical `house/tags.yaml` from the existing tag guide.
- [x] Task 3: Add tag loader/validator, `GET /tags`, and loader persistence for `tag_selections`.
- [x] Task 4: Inject character, scene, and card tags into the prompt.

### Checkpoint: Tag backend
- [x] `npm test` passes
- [x] Unknown/legacy tags do not break listings or chat

### Phase 3: Tag UI
- [x] Task 5: Build reusable searchable/collapsible tag picker and fetch `/tags`.
- [x] Task 6: Integrate picker into character and scene forms with edit/reload round-trip.
- [x] Task 7: Add world-card editing plus tag integration.

### Checkpoint: Tag UI
- [x] `node --check ui/app.js` passes
- [x] Create/edit/reopen preserves `tag_selections` for all three entities
- [x] Selected tags appear in the system prompt

### Phase 4: Group chat room
- [x] Task 8: Make group history scene-scoped and auto-select scene participants.
- [x] Task 9: Harden server group orchestration (mentions, pass, dedupe, cap, named history).
- [x] Task 10: Fix UI response bubbles/status and verify shared timeline behavior.

### Checkpoint: Group chat
- [x] Group test with 3 participants passes
- [x] Shared history includes earlier speaker names
- [x] No duplicate or runaway replies

### Phase 5: Documentation and verification
- [x] Task 11: Update README/help/design docs for sidebar, tags, group chat.
- [x] Task 12: Run full tests, syntax checks, and a live mock-LM-Studio smoke.

### Checkpoint: Complete
- [x] `npm test` passes
- [x] All three note.md features are usable end-to-end
- [x] No existing CRUD/chat behavior regressed

## Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Legacy `tags: [...]` conflicts with structured tags | High | Use separate `tag_selections` field; keep legacy arrays as extras |
| Scene/card serializers drop object fields | High | Explicitly validate and round-trip `tag_selections` |
| Group replies become slow with many characters | Medium | Response cap + `[PASS]` support + sequential streaming |
| Mobile drawer traps focus/scroll | Medium | Backdrop click close, Escape close, body scroll lock, aria attributes |
| Small local models ignore instruction formats | Medium | Deterministic fallback: mentioned-first ordering, cap, dedupe |

## Open Questions

- Scenario templates remain authoring-only; tags are supported on runtime
  scenes. This is documented rather than inventing a scenario runtime.
