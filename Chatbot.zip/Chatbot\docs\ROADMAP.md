# Chatbot — Roadmap

## Roadmap Overview

| Phase   | Focus                | Key Deliverable                                               | Est. Timeline |
| ------- | -------------------- | ------------------------------------------------------------- | ------------- |
| Phase 0 | Scaffolding & docs   | Repo structure, `house/organization.yaml`, characters, scenes | Week 1        |
| Phase 1 | Core chat runtime    | Nick ↔ agent chat via the Chatbot server + LM Studio          | Weeks 2–3     |
| Phase 2 | Scenes & scenarios   | Scene workspaces, agent-to-scene assignment                   | Week 4        |
| Phase 3 | Durable memory       | Obsidian-backed long-term memory                              | Week 5        |
| Phase 4 | World cards          | Location-shift and world card system                          | Week 6        |
| Phase 5 | Character management | Add/edit/delete characters via UI                             | Week 7        |
| Phase 6 | Polish & release     | Testing, UI polish, docs finalized                            | Week 8        |

## Quarter View (Q4 2026)

```
Oct        Nov        Dec
| Phase 0  | Phase 1  | Phase 2  |
| Scaffolding | Core Chat | Scenes   |
            | Phase 3  | Phase 4  |
            | Memory   | World Cards
```

## Dependencies & Risks

| Dependency                                              | Risk                                          | Mitigation                                                   |
| ------------------------------------------------------- | --------------------------------------------- | ------------------------------------------------------------ |
| LM Studio running locally at `http://localhost:1234/v1` | LM Studio not installed or server not running | Document install steps; add startup check in the Chatbot server |
| workspace UI availability                          | UI component may require separate setup       | Build minimal chat UI first; integrate the workspace UI later  |
| Obsidian vault path                                     | Vault location may vary per user              | Make vault path configurable via env var or settings file    |
| Chatbot server runtime                                 | Node.js version compatibility                 | Pin Node.js >= 22; test after upgrades                       |

## Success Metrics

- [ ] All 6 phases completed within 8 weeks.
- [ ] Zero critical bugs blocking chat functionality.
- [ ] Nick can conduct a 10+ turn conversation with an agent without repetition or persona breaks.
- [ ] Memory retrieval works across at least 3 separate sessions.
